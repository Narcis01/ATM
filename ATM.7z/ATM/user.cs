﻿using System;

public class User
{
	String username;
	double balance;


	public User()
	{
	}
}
