﻿using System;

public class User
{
    public String username;

	public String pin;
	public double balance;


	public User()
	{
		balance = 0;

		pin = "0000";

		username = "username";

	}
}
