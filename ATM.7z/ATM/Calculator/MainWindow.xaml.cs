﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        User user1 = new User();
        
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if(input.Text == user1.pin)
            {
                textblock.Text = $"Hello {user1.username}";
                login.Visibility = Visibility.Hidden;
                ADD.Visibility = Visibility.Visible;
                balanceBtn.Visibility = Visibility.Visible;
                withdrawbtn.Visibility = Visibility.Visible;
                exitbtn.Visibility = Visibility.Visible;
            }
            else
            {
                textblock.Text = "Failed";
            }
        }
        int n = 0;
        private void ADD_Click(object sender, RoutedEventArgs e)
        {
            
            if (n % 2 == 0)
            {
                textblock.Text = "How much do you add?";
                input.Text = "";
            }
            else
            {
                user1.balance +=Convert.ToInt32( input.Text);
                textblock.Text = "Money added";
                input.Text = "";
            }
            n++;
        }

        private void balanceBtn_Click(object sender, RoutedEventArgs e)
        {
            textblock.Text = $"Your balance is {user1.balance}";
            input.Text = "";
        }
        int m = 0;
        private void withdrawbtn_Click(object sender, RoutedEventArgs e)
        {   if (m % 2 == 0)
            {
                textblock.Text = "How much money?";
                input.Text = "";
            }
            else
            {
                if(Convert.ToInt32(input.Text) > user1.balance )
                {
                    textblock.Text = "Not enough money!";
                    input.Text = "";
                }
                else
                {
                    user1.balance -= Convert.ToInt32(input.Text);
                    input.Text = "";
                    textblock.Text = "Successful!";
                }

            }
            m++;
        }

        private void exitbtn_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
            
        }
    }
}
